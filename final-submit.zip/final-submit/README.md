# cli-portfolio-manager
A small command line UI to manage portfolio of stocks, bonds, and property into an excel file. 

Function: Create, Read, Update, Delete, Search and Sort portfolio and/or asset in portfolio, then optional export to an excel file. 

Language used: 
- C++


## Planned updates for later

- manage assets according to portfolio
- user login & authentication
- GUI 
- other assets details 


